export interface ScriptChunk {
  id: number;
  text: string;
  wordCount: number;
  status: 'pending' | 'generating' | 'success' | 'error';
  audioBlob?: Blob;
}

export function splitScriptIntoChunks(script: string, targetSize: number = 250): ScriptChunk[] {
  // First, split by natural paragraph breaks
  const paragraphs = script.split(/\n{2,}/).filter(p => p.trim().length > 0);
  const chunks: string[] = [];

  for (const paragraph of paragraphs) {
    // If the paragraph is already small, just add it
    const words = paragraph.split(/\s+/).filter(w => w.length > 0);
    if (words.length <= targetSize + 20) {
      chunks.push(paragraph);
      continue;
    }

    // Otherwise, split the paragraph by sentences, avoiding splitting at commas or colons.
    // This keeps dialogue and names connected.
    const sentences = paragraph.match(/[^.?!؟\n]+(?:[.?!؟\n]+["'”’»]*)*(?:\s+|$)/g)?.map(s => s.trim()).filter(s => s.length > 0) || [paragraph];
    
    let currentChunk = "";
    let currentWordCount = 0;

    for (const sentence of sentences) {
      const sentenceWords = sentence.split(/\s+/).filter(w => w.length > 0);
      const sentenceWordCount = sentenceWords.length;

      if (currentWordCount + sentenceWordCount > targetSize && currentWordCount >= 30) {
        // Push the current chunk and start a new one
        chunks.push(currentChunk.trim());
        currentChunk = sentence;
        currentWordCount = sentenceWordCount;
      } else {
        // Add to current chunk
        currentChunk = currentChunk ? currentChunk + " " + sentence : sentence;
        currentWordCount += sentenceWordCount;
      }
    }

    if (currentChunk.trim().length > 0) {
      chunks.push(currentChunk.trim());
    }
  }

  // Create the final chunk objects
  return chunks.map((chunk, index) => {
    return {
      id: index + 1,
      text: chunk,
      wordCount: chunk.split(/\s+/).filter(w => w.length > 0).length,
      status: 'pending'
    };
  });
}
