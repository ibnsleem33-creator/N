export type EnhancementLevel = 'Light' | 'Balanced' | 'Strong';
export type SilenceMode = 'Light' | 'Balanced' | 'Aggressive';

export interface ProcessOptions {
  blob: Blob;
  enhance: boolean;
  removeSilence: boolean;
  enhancementLevel: EnhancementLevel;
  silenceMode: SilenceMode;
}

export const processAudio = async (options: ProcessOptions): Promise<{ blob: Blob, duration: number, originalDuration: number }> => {
  const arrayBuffer = await options.blob.arrayBuffer();
  
  // Use offline context at 24000Hz to preserve sample rate
  const AudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  let audioContext = new AudioContextClass(1, 1, 24000);
  let audioBuffer = await audioContext.decodeAudioData(arrayBuffer);
  
  const originalDuration = audioBuffer.duration;
  let currentBuffer = audioBuffer;

  if (options.removeSilence) {
    currentBuffer = removeSilences(currentBuffer, options.silenceMode);
  }

  if (options.enhance) {
    currentBuffer = await enhanceVoice(currentBuffer, options.enhancementLevel);
  }

  // Normalize and convert to WAV 16-bit
  const wavBlob = audioBufferToWav(currentBuffer);
  return { blob: wavBlob, duration: currentBuffer.duration, originalDuration };
};

function removeSilences(buffer: AudioBuffer, mode: SilenceMode): AudioBuffer {
  const channelData = buffer.getChannelData(0);
  const sampleRate = buffer.sampleRate;
  
  let thresholdDb = -42;
  let minSilenceMs = 400;
  let keepPaddingMs = 150;
  
  if (mode === 'Light') {
    thresholdDb = -48;
    minSilenceMs = 600;
    keepPaddingMs = 250;
  } else if (mode === 'Aggressive') {
    thresholdDb = -35;
    minSilenceMs = 250;
    keepPaddingMs = 100;
  }

  const threshold = Math.pow(10, thresholdDb / 20);
  const windowSize = Math.floor(sampleRate * 0.01); // 10ms
  
  const envelope = new Float32Array(Math.ceil(channelData.length / windowSize));
  for (let i = 0; i < envelope.length; i++) {
    let sum = 0;
    const start = i * windowSize;
    const end = Math.min(start + windowSize, channelData.length);
    for (let j = start; j < end; j++) {
      sum += channelData[j] * channelData[j];
    }
    envelope[i] = Math.sqrt(sum / (end - start));
  }

  const isSpeech = new Uint8Array(envelope.length);
  for (let i = 0; i < envelope.length; i++) {
    isSpeech[i] = envelope[i] > threshold ? 1 : 0;
  }

  const padBlocks = Math.ceil((keepPaddingMs / 1000) * sampleRate / windowSize);
  const minSilenceBlocks = Math.ceil((minSilenceMs / 1000) * sampleRate / windowSize);

  const paddedSpeech = new Uint8Array(isSpeech.length);
  for (let i = 0; i < isSpeech.length; i++) {
    if (isSpeech[i]) {
      const start = Math.max(0, i - padBlocks);
      const end = Math.min(isSpeech.length, i + padBlocks + 1);
      for (let j = start; j < end; j++) {
        paddedSpeech[j] = 1;
      }
    }
  }

  let silenceStart = -1;
  for (let i = 0; i < paddedSpeech.length; i++) {
    if (paddedSpeech[i] === 0) {
      if (silenceStart === -1) silenceStart = i;
    } else {
      if (silenceStart !== -1) {
        const silenceLen = i - silenceStart;
        if (silenceLen < minSilenceBlocks) {
          for (let j = silenceStart; j < i; j++) {
            paddedSpeech[j] = 1;
          }
        }
        silenceStart = -1;
      }
    }
  }
  if (silenceStart !== -1) {
    const silenceLen = paddedSpeech.length - silenceStart;
    if (silenceLen < minSilenceBlocks) {
      for (let j = silenceStart; j < paddedSpeech.length; j++) {
        paddedSpeech[j] = 1;
      }
    }
  }

  const keepRegions: {start: number, end: number}[] = [];
  let regionStart = -1;
  for (let i = 0; i < paddedSpeech.length; i++) {
    if (paddedSpeech[i] === 1 && regionStart === -1) {
      regionStart = i;
    } else if (paddedSpeech[i] === 0 && regionStart !== -1) {
      keepRegions.push({
        start: regionStart * windowSize,
        end: Math.min(i * windowSize, channelData.length)
      });
      regionStart = -1;
    }
  }
  if (regionStart !== -1) {
    keepRegions.push({
      start: regionStart * windowSize,
      end: channelData.length
    });
  }

  if (keepRegions.length === 0) return buffer;

  const crossfadeSamples = Math.floor(sampleRate * 0.015); // 15ms
  let totalLength = 0;
  for (let i = 0; i < keepRegions.length; i++) {
    totalLength += (keepRegions[i].end - keepRegions[i].start);
    if (i > 0) totalLength -= crossfadeSamples;
  }

  const outData = new Float32Array(totalLength);
  let outPos = 0;

  for (let i = 0; i < keepRegions.length; i++) {
    const region = keepRegions[i];
    const len = region.end - region.start;
    
    if (i === 0) {
      outData.set(channelData.subarray(region.start, region.end), outPos);
      outPos += len;
    } else {
      const cfStartOut = outPos - crossfadeSamples;
      const cfStartIn = region.start;
      for (let j = 0; j < crossfadeSamples; j++) {
        const t = j / crossfadeSamples;
        outData[cfStartOut + j] = outData[cfStartOut + j] * (1 - t) + channelData[cfStartIn + j] * t;
      }
      outData.set(channelData.subarray(cfStartIn + crossfadeSamples, region.end), cfStartOut + crossfadeSamples);
      outPos += len - crossfadeSamples;
    }
  }

  const AudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const ctx = new AudioContextClass(1, outData.length, sampleRate);
  const outBuffer = ctx.createBuffer(1, outData.length, sampleRate);
  outBuffer.getChannelData(0).set(outData);
  return outBuffer;
}

async function enhanceVoice(buffer: AudioBuffer, level: EnhancementLevel): Promise<AudioBuffer> {
  const sampleRate = buffer.sampleRate;
  const AudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const ctx = new AudioContextClass(1, buffer.length, sampleRate);
  
  const source = ctx.createBufferSource();
  source.buffer = buffer;

  const compressor = ctx.createDynamicsCompressor();
  compressor.knee.value = 10;
  compressor.attack.value = 0.005;
  compressor.release.value = 0.1;
  
  if (level === 'Light') {
    compressor.threshold.value = -15;
    compressor.ratio.value = 2.5;
  } else if (level === 'Balanced') {
    compressor.threshold.value = -18;
    compressor.ratio.value = 3.0;
  } else {
    compressor.threshold.value = -22;
    compressor.ratio.value = 3.5;
  }

  source.connect(compressor);
  compressor.connect(ctx.destination);

  source.start(0);
  const renderedBuffer = await ctx.startRendering();

  const channelData = renderedBuffer.getChannelData(0);
  let maxPeak = 0;
  for (let i = 0; i < channelData.length; i++) {
    const abs = Math.abs(channelData[i]);
    if (abs > maxPeak) maxPeak = abs;
  }

  const targetPeak = Math.pow(10, -1 / 20); // -1 dB
  const scale = maxPeak > 0 ? targetPeak / maxPeak : 1;

  for (let i = 0; i < channelData.length; i++) {
    let val = channelData[i] * scale;
    if (val > 1) val = 1;
    if (val < -1) val = -1;
    channelData[i] = val;
  }

  return renderedBuffer;
}

function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = 1;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;
  
  const pcmData = buffer.getChannelData(0);
  const dataLength = pcmData.length * (bitDepth / 8);
  const bufferLength = 44 + dataLength;
  const arrayBuffer = new ArrayBuffer(bufferLength);
  const view = new DataView(arrayBuffer);

  const writeString = (v: DataView, offset: number, string: string) => {
    for (let i = 0; i < string.length; i++) {
      v.setUint8(offset + i, string.charCodeAt(i));
    }
  };

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + dataLength, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, format, true);
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * numChannels * (bitDepth / 8), true);
  view.setUint16(32, numChannels * (bitDepth / 8), true);
  view.setUint16(34, bitDepth, true);
  writeString(view, 36, 'data');
  view.setUint32(40, dataLength, true);

  const offset = 44;
  for (let i = 0; i < pcmData.length; i++) {
    let s = Math.max(-1, Math.min(1, pcmData[i]));
    view.setInt16(offset + i * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

export const mergeAudioChunks = async (blobs: Blob[], texts?: string[], applyCompression: boolean = true): Promise<Blob> => {
  if (blobs.length === 0) throw new Error("No audio chunks to merge");
  
  const AudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const audioContext = new AudioContextClass(1, 1, 24000);
  
  const buffers: AudioBuffer[] = [];
  for (const blob of blobs) {
    const arrayBuffer = await blob.arrayBuffer();
    const buffer = await audioContext.decodeAudioData(arrayBuffer);
    buffers.push(buffer);
  }

  const sampleRate = buffers[0].sampleRate;
  
  let totalLength = 0;
  const gaps: number[] = [];
  
  for (let i = 0; i < buffers.length; i++) {
    totalLength += buffers[i].length;
    if (i < buffers.length - 1) {
      let gapMs = 80;
      if (texts && texts[i]) {
        const text = texts[i].trim();
        const lastChar = text.charAt(text.length - 1);
        if (['.', '!', '؟', '?'].includes(lastChar)) {
          gapMs = 250;
        } else if (['،', ',', ':'].includes(lastChar)) {
          gapMs = 150;
        }
      }
      const gapSamples = Math.floor(sampleRate * (gapMs / 1000));
      gaps.push(gapSamples);
      totalLength += gapSamples;
    }
  }

  const outData = new Float32Array(totalLength);
  let outPos = 0;

  for (let i = 0; i < buffers.length; i++) {
    const channelData = buffers[i].getChannelData(0);
    outData.set(channelData, outPos);
    outPos += channelData.length;
    
    if (i < buffers.length - 1) {
      outPos += gaps[i];
    }
  }

  // Final Loudness Normalization Pass
  let maxPeak = 0;
  for (let i = 0; i < outData.length; i++) {
    const abs = Math.abs(outData[i]);
    if (abs > maxPeak) maxPeak = abs;
  }
  if (maxPeak > 0) {
    const scale = 0.95 / maxPeak; // safe normalization (-0.5 dB)
    for (let i = 0; i < outData.length; i++) {
      outData[i] *= scale;
    }
  }

  const ctx = new AudioContextClass(1, outData.length, sampleRate);
  const outBuffer = ctx.createBuffer(1, outData.length, sampleRate);
  outBuffer.getChannelData(0).set(outData);

  if (applyCompression) {
    return audioBufferToWav(await applyFinalCompression(outBuffer));
  }
  return audioBufferToWav(outBuffer);
};

async function applyFinalCompression(buffer: AudioBuffer): Promise<AudioBuffer> {
  const sampleRate = buffer.sampleRate;
  const AudioContextClass = window.OfflineAudioContext || (window as any).webkitOfflineAudioContext;
  const ctx = new AudioContextClass(1, buffer.length, sampleRate);
  
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  
  const compressor = ctx.createDynamicsCompressor();
  compressor.knee.value = 10;
  compressor.attack.value = 0.005;
  compressor.release.value = 0.1;
  compressor.threshold.value = -18;
  compressor.ratio.value = 3.0;

  source.connect(compressor);
  compressor.connect(ctx.destination);
  source.start(0);

  const renderedBuffer = await ctx.startRendering();
  
  // Normalize again after compression
  const channelData = renderedBuffer.getChannelData(0);
  let maxPeak = 0;
  for (let i = 0; i < channelData.length; i++) {
    const abs = Math.abs(channelData[i]);
    if (abs > maxPeak) maxPeak = abs;
  }
  if (maxPeak > 0) {
    const scale = 0.95 / maxPeak;
    for (let i = 0; i < channelData.length; i++) {
      channelData[i] *= scale;
    }
  }
  
  return renderedBuffer;
}
