export interface LockedVoiceProfile {
  modelId: string;
  voiceId: string;
  style: string;
  perfPower: string;
  speed: string;
  perfType: string;
  expression: string;
  pauses: string;
  articulation: string;
  tone: string;
  emotionMode: string;
  emotionIntensity: string;
  laughterControl: string;
  sadnessControl: string;
  fixedEmotion: string;
  highVoiceConsistency: boolean;
}

export async function generateVoiceFingerprint(profile: LockedVoiceProfile): Promise<string> {
  const dataString = JSON.stringify(profile);
  const msgUint8 = new TextEncoder().encode(dataString);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  return hashHex.slice(0, 16); // Short fingerprint
}

export function normalizeScript(script: string): string {
  if (!script) return "";
  let normalized = script
    .replace(/[\u200B-\u200D\uFEFF]/g, '') // remove zero-width spaces
    .replace(/\s+/g, ' ') // normalize whitespace
    .replace(/([.?!؟]+)/g, '$1 ') // ensure space after punctuation
    .replace(/\s+([.?!؟]+)/g, '$1') // remove space before punctuation
    .replace(/\s+/g, ' ') // clean up again
    .trim();
  return normalized;
}

export function validateAudioBlob(blob: Blob): Promise<boolean> {
  return new Promise((resolve) => {
    if (!blob || blob.size <= 44) { // WAV header is 44 bytes
      resolve(false);
      return;
    }
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        const decoded = await audioContext.decodeAudioData(arrayBuffer);
        if (decoded.duration > 0 && decoded.sampleRate > 0) {
          resolve(true);
        } else {
          resolve(false);
        }
      } catch (err) {
        resolve(false);
      } finally {
        if (audioContext.state !== 'closed') {
          audioContext.close();
        }
      }
    };
    reader.onerror = () => resolve(false);
    reader.readAsArrayBuffer(blob);
  });
}
