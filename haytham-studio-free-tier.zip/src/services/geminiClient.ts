import {GoogleGenAI, Modality} from "@google/genai";
import type {LockedVoiceProfile} from "../utils/voiceConsistency";

export interface EmotionSegment {
  text: string;
  emotion: string;
}

type StructuredQuotaError = {
  status: 429;
  errorType: "quota";
  quotaType: "RPM" | "RPD" | "TPM" | "UNKNOWN";
  retryAfterMs: number | null;
  modelId: string;
  message: string;
};

const TTS_MODEL = "gemini-2.5-flash-preview-tts";
const ANALYSIS_MODEL = "gemini-2.5-flash";

function getClient(): GoogleGenAI {
  const apiKey = process.env.API_KEY as string | undefined;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    const error: any = new Error(
      "اختَر AI Studio Free Tier أو مفتاح Gemini الخاص بالحساب الحالي من قائمة Secrets ثم أعد تحميل التطبيق."
    );
    error.status = 401;
    throw error;
  }
  return new GoogleGenAI({apiKey});
}

function normalizeApiError(raw: any): never {
  const message = String(raw?.message || raw || "حدث خطأ أثناء الاتصال بـ Gemini.");
  const status =
    Number(raw?.status || raw?.code) ||
    (message.includes("429") || /quota|resource_exhausted/i.test(message) ? 429 :
      message.includes("503") || /unavailable|overloaded/i.test(message) ? 503 :
        message.includes("400") || /invalid.argument/i.test(message) ? 400 : 500);

  const error: any = new Error(message);
  error.status = status;

  if (status === 429) {
    let quotaType: StructuredQuotaError["quotaType"] = "UNKNOWN";
    if (/RPD|per.?day|daily/i.test(message)) quotaType = "RPD";
    else if (/RPM|per.?minute|requests.?per.?minute/i.test(message)) quotaType = "RPM";
    else if (/TPM|token/i.test(message)) quotaType = "TPM";

    error.structuredError = {
      status: 429,
      errorType: "quota",
      quotaType,
      retryAfterMs: null,
      modelId: TTS_MODEL,
      message,
    } satisfies StructuredQuotaError;
  }

  throw error;
}

const STYLE_INSTRUCTIONS: Record<string, string> = {
  "ملخصات مصري سريع": "Speak in natural Egyptian Arabic with a youthful, confident, energetic recap voice. Use a moderately fast continuous rhythm, very short pauses, crisp articulation, firm sentence endings, and subtle dry Egyptian sarcasm. Never shout or become breathless.",
  "مصري طبيعي": "Speak in natural Egyptian Arabic with a warm, friendly, conversational young-adult voice, authentic pronunciation, smooth connections, and short natural pauses.",
  "خليجي طبيعي": "Speak in natural Gulf Arabic with a warm, modern, confident young-adult voice. Use authentic Gulf rhythm, clear pronunciation, and natural pauses.",
  "فصحى احترافية": "Speak in clear Modern Standard Arabic with accurate formal pronunciation, balanced pacing, confident articulation, and a polished professional narrator voice.",
  "عربي محايد": "Speak in clear neutral Arabic understood across Arabic-speaking countries. Use a modern, friendly, balanced tone and avoid strong regional dialect features.",
  "مصري نسائي طبيعي": "Speak in natural Egyptian Arabic with a warm, friendly, conversational young-adult female voice and authentic Egyptian pronunciation.",
  "مصري نسائي حماسي": "Speak in natural Egyptian Arabic with an energetic young female voice. Keep it bright, lively and engaging at a moderately fast pace without sounding childish or cartoonish.",
  "خليجي نسائي طبيعي": "Speak in natural Gulf Arabic with a warm, modern, confident young-adult female voice, authentic rhythm, clear pronunciation, and natural pauses.",
  "خليجي نسائي راقي": "Speak in natural Gulf Arabic with an elegant adult female voice. Use a polished, calm, confident, refined delivery with restrained emotion.",
  "فصحى نسائية": "Speak in clear Modern Standard Arabic with a professional adult female voice, accurate formal pronunciation, balanced pacing, and confident articulation.",
  "عربي نسائي محايد": "Speak in clear neutral Arabic with a modern, friendly, balanced adult female voice understood across Arabic-speaking countries.",
};

const PERF_POWER: Record<string, string> = {
  "ضعيف": "calm and soft with restrained vocal pressure",
  "متوازن": "clear and natural with controlled energy",
  "قوي": "confident and powerful with strong emphasis but no shouting",
};

const SPEED: Record<string, string> = {
  "بطيء": "slow with clear pronunciation and longer natural pauses",
  "متوازن": "a natural conversational pace",
  "سريع": "moderately fast with short pauses while keeping every syllable clear",
  "سريع جدًا": "very fast and continuous with minimal pauses, without mumbling",
};

const PERF_TYPE: Record<string, string> = {
  "طبيعي": "conversational and realistic",
  "راوي": "controlled professional narration",
  "قصصي": "expressive storytelling with natural scene changes",
  "ملخصات": "fast, energetic recap narration with strong transitions",
  "بودكاست": "warm, intimate, close-microphone conversation",
  "وثائقي": "professional, composed documentary narration",
  "إعلاني": "bright, polished and persuasive",
  "إخباري": "formal, precise and steady",
  "حماسي": "lively, sharp and motivating",
  "هادئ": "smooth, relaxed and reassuring",
  "درامي": "controlled tension and emotional weight",
  "كوميدي": "playful timing and subtle dry humor",
};

const EXPRESSION: Record<string, string> = {
  "منخفض": "Keep emotional changes subtle.",
  "متوازن": "Use natural emotional variation.",
  "مرتفع": "Use noticeable but believable emotional variation without theatrical overacting.",
};

const PAUSES: Record<string, string> = {
  "قليلة جدًا": "Use extremely short pauses and keep the flow continuous.",
  "قليلة": "Use short pauses.",
  "متوازنة": "Use natural punctuation-aware pauses.",
  "طويلة": "Use longer deliberate pauses at important moments.",
};

const ARTICULATION: Record<string, string> = {
  "طبيعي": "Use natural conversational articulation.",
  "واضح": "Pronounce all words clearly.",
  "واضح جدًا": "Use crisp, highly precise articulation without sounding robotic.",
};

const TONE: Record<string, string> = {
  "ودية": "friendly",
  "واثقة": "confident",
  "جادة": "serious",
  "ساخرة": "subtly sarcastic",
  "دافئة": "warm",
  "رسمية": "formal and restrained",
  "غامضة": "mysterious with controlled tension",
  "ملحمية": "epic and weighty without shouting",
};

function buildSpeechPrompt(
  script: string,
  profile: LockedVoiceProfile,
  emotionInstructions: string,
): string {
  const performance = [
    `Vocal power: ${PERF_POWER[profile.perfPower] || profile.perfPower}.`,
    `Speaking speed: ${SPEED[profile.speed] || profile.speed}.`,
    `Performance type: ${PERF_TYPE[profile.perfType] || profile.perfType}.`,
    EXPRESSION[profile.expression] || "",
    PAUSES[profile.pauses] || "",
    ARTICULATION[profile.articulation] || "",
    `Overall tone: ${TONE[profile.tone] || profile.tone}.`,
  ].filter(Boolean).join("\n");

  const emotionLimit = profile.highVoiceConsistency
    ? "Keep emotional intensity controlled. Emotion may affect pacing, emphasis and pauses only; it must never change the speaker identity, timbre, accent, gender, vocal age or base tone."
    : `Emotion intensity: ${profile.emotionIntensity}.`;

  const emotionSection = emotionInstructions
    ? `${emotionLimit}\nLaughter: ${profile.laughterControl}. Sadness: ${profile.sadnessControl}.\n${emotionInstructions}`
    : "No special emotion directions. Keep the natural meaning of the text.";

  return `Follow these private speaking instructions. Never read any instruction, heading, label, bracketed emotion, or setting aloud. Speak only the exact text in SCRIPT.

FIXED SPEAKER IDENTITY — identical for every part:
Use prebuilt voice ${profile.voiceId}.
${STYLE_INSTRUCTIONS[profile.style] || profile.style}
${performance}

VOICE LOCK:
Maintain exactly the same speaker identity, accent, gender, apparent age, vocal weight, timbre, narrator personality and microphone distance across all parts. Begin this part in the same base voice as every other part. Do not imitate a new character voice.

EMOTIONAL PERFORMANCE FOR THIS PART:
${emotionSection}

SCRIPT — SPEAK ONLY THESE EXACT WORDS:
${script}`;
}

function decodeBase64(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function pcmToWav(pcmParts: Uint8Array[], sampleRate = 24000): Blob {
  const dataLength = pcmParts.reduce((sum, part) => sum + part.byteLength, 0);
  const wav = new ArrayBuffer(44 + dataLength);
  const view = new DataView(wav);
  const write = (offset: number, value: string) => {
    for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i));
  };

  write(0, "RIFF");
  view.setUint32(4, 36 + dataLength, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, dataLength, true);

  const output = new Uint8Array(wav);
  let offset = 44;
  for (const part of pcmParts) {
    output.set(part, offset);
    offset += part.byteLength;
  }
  return new Blob([wav], {type: "audio/wav"});
}

export async function analyzeEmotionsClient(
  script: string,
  presetContext = "",
): Promise<EmotionSegment[]> {
  const context = presetContext ? `Special focus: ${presetContext}\n` : "";
  const prompt = `Analyze this Arabic script for spoken narration.
Supported emotions: طبيعي, سعيد, ضحك خفيف, ضحك واضح, حزين, مؤثر, غاضب, خائف, متوتر, متحمس, مندهش, ساخر, غامض, جاد, هادئ, واثق, محبط, متوسل, ملحمي.
${context}Split it into complete meaningful segments. Use restrained, believable emotions and smooth transitions. Preserve every original word exactly and in order.
Return only a JSON array with objects shaped as {"text":"exact original segment","emotion":"one supported emotion"}.

SCRIPT:
${script}`;

  try {
    const response = await getClient().models.generateContent({
      model: ANALYSIS_MODEL,
      contents: [{parts: [{text: prompt}]}],
      config: {responseMimeType: "application/json"},
    });
    const parsed = JSON.parse(response.text || "[]");
    if (!Array.isArray(parsed)) throw new Error("Emotion analysis did not return an array.");
    return parsed.filter(item => item && typeof item.text === "string" && typeof item.emotion === "string");
  } catch (error) {
    normalizeApiError(error);
  }
}

export async function generateSpeechClient(
  script: string,
  profile: LockedVoiceProfile,
  emotionInstructions = "",
): Promise<Blob> {
  try {
    const response = await getClient().models.generateContent({
      model: TTS_MODEL,
      contents: [{parts: [{text: buildSpeechPrompt(script, profile, emotionInstructions)}]}],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: {voiceName: profile.voiceId},
          },
        },
      },
    });

    const audioParts = (response.candidates?.[0]?.content?.parts || [])
      .map(part => part.inlineData)
      .filter(data => data?.data && data.mimeType?.startsWith("audio/"))
      .map(data => decodeBase64(data!.data!));

    if (audioParts.length === 0) {
      const error: any = new Error("لم يرجع Gemini أي صوت لهذا الجزء.");
      error.status = 503;
      throw error;
    }
    return pcmToWav(audioParts);
  } catch (error) {
    normalizeApiError(error);
  }
}
