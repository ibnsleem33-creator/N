/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from "react";
import { Play, Download, Loader2, AlertCircle, Volume2, CheckCircle2, Wand2, Scissors, RotateCcw, Edit2, Trash2, Settings, ChevronDown, ChevronUp, Sparkles, Cpu, Layers, Mic2, Activity } from "lucide-react";
import { splitScriptIntoChunks, ScriptChunk } from "./utils/chunkProcessor";
import { mergeAudioChunks } from "./utils/audioProcessor";
import { processAudio, EnhancementLevel, SilenceMode } from "./utils/audioProcessor";
import { LockedVoiceProfile, generateVoiceFingerprint, normalizeScript, validateAudioBlob } from "./utils/voiceConsistency";
import { analyzeEmotionsClient, generateSpeechClient } from "./services/geminiClient";

const VOICES = ["Puck", "Charon", "Kore", "Fenrir", "Zephyr", "Aoede"];
const VOICE_GENDERS: Record<string, "male" | "female"> = {
  Puck: "male",
  Charon: "male",
  Kore: "female",
  Fenrir: "male",
  Zephyr: "male",
  Aoede: "female",
};

const STYLES = [
  "ملخصات مصري سريع",
  "مصري طبيعي",
  "خليجي طبيعي",
  "فصحى احترافية",
  "عربي محايد",
  "مصري نسائي طبيعي",
  "مصري نسائي حماسي",
  "خليجي نسائي طبيعي",
  "خليجي نسائي راقي",
  "فصحى نسائية",
  "عربي نسائي محايد",
];

const STYLE_GENDER_REQ: Record<string, "male" | "female" | "any"> = {
  "ملخصات مصري سريع": "male",
  "مصري طبيعي": "male",
  "خليجي طبيعي": "male",
  "فصحى احترافية": "male",
  "عربي محايد": "male",
  "مصري نسائي طبيعي": "female",
  "مصري نسائي حماسي": "female",
  "خليجي نسائي طبيعي": "female",
  "خليجي نسائي راقي": "female",
  "فصحى نسائية": "female",
  "عربي نسائي محايد": "female",
};

const PRESETS: Record<string, any> = {
  "ملخص أنمي سريع": { perfPower: "قوي", speed: "سريع", perfType: "ملخصات", expression: "مرتفع", pauses: "قليلة جدًا", articulation: "واضح جدًا", tone: "واثقة" },
  "راوي قصصي": { perfPower: "متوازن", speed: "متوازن", perfType: "قصصي", expression: "مرتفع", pauses: "متوازنة", articulation: "واضح", tone: "دافئة" },
  "بودكاست هادئ": { perfPower: "ضعيف", speed: "متوازن", perfType: "بودكاست", expression: "منخفض", pauses: "متوازنة", articulation: "واضح", tone: "ودية" },
  "وثائقي احترافي": { perfPower: "متوازن", speed: "متوازن", perfType: "وثائقي", expression: "متوازن", pauses: "متوازنة", articulation: "واضح جدًا", tone: "جادة" },
  "إعلان حماسي": { perfPower: "قوي", speed: "سريع", perfType: "إعلاني", expression: "مرتفع", pauses: "قليلة", articulation: "واضح جدًا", tone: "واثقة" },
  "أخبار رسمية": { perfPower: "متوازن", speed: "متوازن", perfType: "إخباري", expression: "منخفض", pauses: "متوازنة", articulation: "واضح جدًا", tone: "رسمية" },
  "كوميدي خفيف": { perfPower: "متوازن", speed: "سريع", perfType: "كوميدي", expression: "مرتفع", pauses: "قليلة", articulation: "واضح", tone: "ساخرة" },
  "درامي غامض": { perfPower: "متوازن", speed: "بطيء", perfType: "درامي", expression: "مرتفع", pauses: "طويلة", articulation: "واضح", tone: "غامضة" },
};

const OPTIONS_PERF_POWER = ["ضعيف", "متوازن", "قوي"];
const OPTIONS_SPEED = ["بطيء", "متوازن", "سريع", "سريع جدًا"];
const OPTIONS_PERF_TYPE = ["طبيعي", "راوي", "قصصي", "ملخصات", "بودكاست", "وثائقي", "إعلاني", "إخباري", "حماسي", "هادئ", "درامي", "كوميدي"];
const OPTIONS_EXPRESSION = ["منخفض", "متوازن", "مرتفع"];
const OPTIONS_PAUSES = ["قليلة جدًا", "قليلة", "متوازنة", "طويلة"];
const OPTIONS_ARTICULATION = ["طبيعي", "واضح", "واضح جدًا"];
const OPTIONS_TONE = ["ودية", "واثقة", "جادة", "ساخرة", "دافئة", "رسمية", "غامضة", "ملحمية"];

const SUPPORTED_EMOTIONS = ["طبيعي", "سعيد", "ضحك خفيف", "ضحك واضح", "حزين", "مؤثر", "غاضب", "خائف", "متوتر", "متحمس", "مندهش", "ساخر", "غامض", "جاد", "هادئ", "واثق", "محبط", "متوسل", "ملحمي"];
const EMOTION_MODES = ["تلقائي بالذكاء الاصطناعي", "شعور ثابت للنص كاملًا", "تحديد يدوي داخل النص"];
const EMOTION_INTENSITIES = ["خفيفة", "متوازنة", "قوية"];
const LAUGHTER_OPTIONS = ["بدون ضحك", "ضحكة خفيفة", "ضحك طبيعي", "تلقائي حسب النص"];
const SADNESS_OPTIONS = ["بدون", "حزن خفيف", "حزن واضح", "تلقائي حسب النص"];

const EMOTION_PRESETS: Record<string, any> = {
  "تلقائي طبيعي": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "متوازنة", laughter: "تلقائي حسب النص", sadness: "تلقائي حسب النص", context: "" },
  "كوميدي": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "متوازنة", laughter: "ضحك طبيعي", sadness: "بدون", context: "Focus on subtle humor and sarcasm" },
  "حزين ومؤثر": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "قوية", laughter: "بدون ضحك", sadness: "حزن واضح", context: "Prioritize clear sadness and emotional weight" },
  "أكشن وحماس": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "قوية", laughter: "بدون ضحك", sadness: "بدون", context: "Prioritize excitement, urgency, confidence, and surprise" },
  "رعب وتوتر": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "متوازنة", laughter: "بدون ضحك", sadness: "بدون", context: "Prioritize fear, mystery, tension, and controlled suspense" },
  "درامي": { enabled: true, mode: "تلقائي بالذكاء الاصطناعي", intensity: "قوية", laughter: "بدون ضحك", sadness: "تلقائي حسب النص", context: "Prioritize emotional changes, serious tone, and important pauses" },
  "بدون مشاعر": { enabled: false }
};

export default function App() {
  const [script, setScript] = useState("");
  const [voice, setVoice] = useState(() => {
    const saved = localStorage.getItem('tts_voice');
    return saved && VOICES.includes(saved) ? saved : VOICES[0];
  });
  const [style, setStyle] = useState(() => {
    const saved = localStorage.getItem('tts_style');
    return saved && STYLES.includes(saved) ? saved : STYLES[0];
  });
  const [notice, setNotice] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [audioData, setAudioData] = useState<string | null>(null);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [originalAudioBlob, setOriginalAudioBlob] = useState<Blob | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processSuccess, setProcessSuccess] = useState<string | null>(null);
  const [enhancementLevel, setEnhancementLevel] = useState<EnhancementLevel>("Balanced");
  const [silenceMode, setSilenceMode] = useState<SilenceMode>("Balanced");
  const [originalDuration, setOriginalDuration] = useState<number | null>(null);
  const [processedDuration, setProcessedDuration] = useState<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Performance Settings
  const [perfPower, setPerfPower] = useState(() => localStorage.getItem('tts_perfPower') || "متوازن");
  const [speed, setSpeed] = useState(() => localStorage.getItem('tts_speed') || "متوازن");
  const [perfType, setPerfType] = useState(() => localStorage.getItem('tts_perfType') || "طبيعي");
  const [expression, setExpression] = useState(() => localStorage.getItem('tts_expression') || "متوازن");
  const [pauses, setPauses] = useState(() => localStorage.getItem('tts_pauses') || "متوازنة");
  const [articulation, setArticulation] = useState(() => localStorage.getItem('tts_articulation') || "واضح");
  const [tone, setTone] = useState(() => localStorage.getItem('tts_tone') || "واثقة");
  const [chunkSize, setChunkSize] = useState<string>("تلقائي ذكي");
  const [chunks, setChunks] = useState<ScriptChunk[]>([]);
  const [isGeneratingChunks, setIsGeneratingChunks] = useState(false);
  const [progressText, setProgressText] = useState("");
  const [progressPercent, setProgressPercent] = useState(0);
  const [isChunksPreviewOpen, setIsChunksPreviewOpen] = useState(false);
  const [voiceFingerprint, setVoiceFingerprint] = useState<string | null>(null);
  const [lockedProfile, setLockedProfile] = useState<LockedVoiceProfile | null>(null);

  const [activePreset, setActivePreset] = useState(() => localStorage.getItem('tts_preset') || "مخصص");
  const [customPresets, setCustomPresets] = useState<Record<string, any>>(() => {
    try {
      return JSON.parse(localStorage.getItem("tts_custom_presets") || "{}");
    } catch {
      return {};
    }
  });
  const [lastSelectedPreset, setLastSelectedPreset] = useState(() => localStorage.getItem('tts_lastSelectedPreset') || "ملخص أنمي سريع");
  const [isPerfSettingsOpen, setIsPerfSettingsOpen] = useState(false);

  // New states for optimization
  const [genMode, setGenMode] = useState(() => localStorage.getItem('tts_genMode') || "توليد كل الأجزاء معًا");
  const [highVoiceConsistency, setHighVoiceConsistency] = useState(() => {
    const saved = localStorage.getItem('tts_highVoiceConsistency');
    return saved ? saved === 'true' : true;
  });
  const [applyFinalCompression, setApplyFinalCompression] = useState(() => {
    const saved = localStorage.getItem('tts_applyFinalCompression');
    return saved ? saved === 'true' : false;
  });
  const [reqDelay, setReqDelay] = useState(() => localStorage.getItem('tts_reqDelay') || "بدون تأخير");
  const [actualReqCount, setActualReqCount] = useState(0);
  const currentJobIdRef = useRef<string | null>(null);
  const activeProfileRef = useRef<LockedVoiceProfile | null>(null);
  const activeFingerprintRef = useRef<string | null>(null);

  const getDelayMs = (delayStr: string) => {
    if (delayStr === "5 ثوانٍ") return 5000;
    if (delayStr === "10 ثوانٍ") return 10000;
    if (delayStr === "20 ثانية") return 20000;
    return 0;
  };

  const getEffectiveTargetSize = (wordCount: number) => {
    if (chunkSize === "تلقائي ذكي") {
      if (wordCount <= 500) return 175;
      return 250;
    }
    const sizeMap: Record<string, number> = {
      "100 كلمة": 100,
      "150 كلمة": 150,
      "200 كلمة": 200,
      "250 كلمة": 250,
      "300 كلمة": 300,
    };
    return sizeMap[chunkSize] || 250;
  };

  const calculateStats = () => {
    const text = script.trim();
    if (!text) return null;
    const totalChars = text.length;
    const words = text.split(/\s+/).filter(w => w.length > 0).length;
    const effectiveTargetSize = getEffectiveTargetSize(words);
    const tempChunks = splitScriptIntoChunks(script, effectiveTargetSize);
    const totalChunks = tempChunks.length;
    const ttsRequests = totalChunks;
    const analysisReqs = (smartEmotionsEnabled && emotionMode === "تلقائي بالذكاء الاصطناعي") ? 1 : 0;
    const totalExpected = ttsRequests + analysisReqs;

    return { totalChars, words, totalChunks, ttsRequests, analysisReqs, totalExpected, effectiveTargetSize };
  };

  const handlePerfChange = (setter: React.Dispatch<React.SetStateAction<any>>, key: string, value: string) => {
    setter(value);
    localStorage.setItem(key, value);
    setActivePreset("مخصص");
    localStorage.setItem('tts_preset', "مخصص");
  };

  const applyPreset = (presetName: string, settings: any) => {
    setPerfPower(settings.perfPower); localStorage.setItem('tts_perfPower', settings.perfPower);
    setSpeed(settings.speed); localStorage.setItem('tts_speed', settings.speed);
    setPerfType(settings.perfType); localStorage.setItem('tts_perfType', settings.perfType);
    setExpression(settings.expression); localStorage.setItem('tts_expression', settings.expression);
    setPauses(settings.pauses); localStorage.setItem('tts_pauses', settings.pauses);
    setArticulation(settings.articulation); localStorage.setItem('tts_articulation', settings.articulation);
    setTone(settings.tone); localStorage.setItem('tts_tone', settings.tone);
    setActivePreset(presetName); localStorage.setItem('tts_preset', presetName);
    setLastSelectedPreset(presetName); localStorage.setItem('tts_lastSelectedPreset', presetName);
  };

  const deleteCustomPreset = (name: string) => {
    if (window.confirm(`هل أنت متأكد من حذف الإعداد الجاهز "${name}"؟`)) {
      const custom = { ...customPresets };
      delete custom[name];
      setCustomPresets(custom);
      localStorage.setItem("tts_custom_presets", JSON.stringify(custom));
      if (activePreset === name) {
        setActivePreset("مخصص");
        localStorage.setItem('tts_preset', "مخصص");
      }
    }
  };

  const renameCustomPreset = (oldName: string) => {
    const newName = window.prompt("الاسم الجديد للإعداد الجاهز:", oldName);
    if (newName && newName !== oldName && !PRESETS[newName] && !customPresets[newName]) {
      const custom = { ...customPresets };
      custom[newName] = custom[oldName];
      delete custom[oldName];
      setCustomPresets(custom);
      localStorage.setItem("tts_custom_presets", JSON.stringify(custom));
      if (activePreset === oldName) {
        setActivePreset(newName);
        localStorage.setItem('tts_preset', newName);
      }
      if (lastSelectedPreset === oldName) {
        setLastSelectedPreset(newName);
        localStorage.setItem('tts_lastSelectedPreset', newName);
      }
    }
  };

  const handleStyleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStyle = e.target.value;
    setStyle(newStyle);
    localStorage.setItem('tts_style', newStyle);

    const requiredGender = STYLE_GENDER_REQ[newStyle];
    if (requiredGender !== "any" && VOICE_GENDERS[voice] !== requiredGender) {
      const compatibleVoice = VOICES.find(v => VOICE_GENDERS[v] === requiredGender);
      if (compatibleVoice) {
        setVoice(compatibleVoice);
        localStorage.setItem('tts_voice', compatibleVoice);
        setNotice(`Voice automatically switched to ${compatibleVoice} to match the selected style gender.`);
        
        // Hide notice after 5 seconds
        setTimeout(() => setNotice(null), 5000);
      }
    } else {
      setNotice(null);
    }
  };

  // Smart Emotions Settings
  const [smartEmotionsEnabled, setSmartEmotionsEnabled] = useState(false);
  const [emotionMode, setEmotionMode] = useState("تلقائي بالذكاء الاصطناعي"); // 1, 2, 3
  const [emotionIntensity, setEmotionIntensity] = useState("متوازنة");
  const [laughterControl, setLaughterControl] = useState("تلقائي حسب النص");
  const [sadnessControl, setSadnessControl] = useState("تلقائي حسب النص");
  const [fixedEmotion, setFixedEmotion] = useState("طبيعي");
  const [manualEmotions, setManualEmotions] = useState<{text: string, emotion: string}[]>([]);
  
  const [isEmotionsPanelOpen, setIsEmotionsPanelOpen] = useState(false);
  const [isAnalyzingEmotions, setIsAnalyzingEmotions] = useState(false);
  const [emotionAnalysis, setEmotionAnalysis] = useState<{text: string, emotion: string}[] | null>(null);
  const [emotionAnalysisError, setEmotionAnalysisError] = useState<string | null>(null);
  const [emotionsPresetContext, setEmotionsPresetContext] = useState("");

  const applyEmotionPreset = (presetName: string, settings: any) => {
    if (settings.enabled !== undefined) setSmartEmotionsEnabled(settings.enabled);
    if (settings.mode) setEmotionMode(settings.mode);
    if (settings.intensity) setEmotionIntensity(settings.intensity);
    if (settings.laughter) setLaughterControl(settings.laughter);
    if (settings.sadness) setSadnessControl(settings.sadness);
    if (settings.context !== undefined) setEmotionsPresetContext(settings.context);
  };

  const handleAnalyzeEmotions = async (isAutoAnalyze = false) => {
    if (isAnalyzingEmotions || isLoading || isProcessing) return null;
    if (!script.trim()) return null;
    setIsAnalyzingEmotions(true);
    setEmotionAnalysisError(null);
    try {
      setActualReqCount(prev => prev + 1);
      const analysis = await analyzeEmotionsClient(script, emotionsPresetContext);
      setEmotionAnalysis(analysis);
      return analysis;
    } catch (err: any) {
      let errorMsg = err.message || "حدث خطأ غير متوقع في التحليل.";
      if (errorMsg === "Analysis failed") errorMsg = "فشل في تحليل المشاعر. تأكد من أن النص صالح.";
      setEmotionAnalysisError(errorMsg);
      return null;
    } finally {
      setIsAnalyzingEmotions(false);
    }
    return null;
  };

  const generateChunk = async (chunk: ScriptChunk, emotionInstructionsText: string, jobId: string, profile: LockedVoiceProfile): Promise<Blob> => {
    if (currentJobIdRef.current !== jobId) throw new Error("Job Cancelled");
    setActualReqCount(prev => prev + 1);
    const wavBlob = await generateSpeechClient(chunk.text, profile, emotionInstructionsText);
    
    const isValid = await validateAudioBlob(wavBlob);
    if (!isValid) {
       throw new Error("Invalid audio generated (validation failed).");
    }

    return wavBlob;
  };

  const handleRetryChunk = async (chunkId: number) => {
    const chunkIndex = chunks.findIndex(c => c.id === chunkId);
    if (chunkIndex === -1) return;

    if (currentJobIdRef.current) return; // Wait if another job is running
    const jobId = Date.now().toString();
    currentJobIdRef.current = jobId;

    setIsLoading(true);
    setIsGeneratingChunks(true);
    setError(null);
    setProgressText(`إعادة توليد الجزء ${chunkId} من ${chunks.length}`);

    const newChunks = [...chunks];
    newChunks[chunkIndex].status = 'generating';
    setChunks(newChunks);

    try {
      let emotionInstructionsText = "";
      if (smartEmotionsEnabled) {
        if (emotionMode === "تلقائي بالذكاء الاصطناعي" && emotionAnalysis) {
          const chunkText = newChunks[chunkIndex].text;
          const relevantEmotions = emotionAnalysis.filter((e: any) => chunkText.includes(e.text) || e.text.includes(chunkText));
          emotionInstructionsText = relevantEmotions.length > 0 
            ? relevantEmotions.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n")
            : emotionAnalysis.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n");
        } else if (emotionMode === "شعور ثابت للنص كاملًا") {
           emotionInstructionsText = `Apply the following emotion to the entire script: ${fixedEmotion}`;
        } else if (emotionMode === "تحديد يدوي داخل النص" && manualEmotions.length > 0) {
           emotionInstructionsText = manualEmotions.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n");
        }
      }

      if (!activeProfileRef.current || !activeFingerprintRef.current) {
         throw new Error("Missing voice profile.");
      }
      const blob = await generateChunk(newChunks[chunkIndex], emotionInstructionsText, jobId, activeProfileRef.current);
      if (currentJobIdRef.current !== jobId) return;
      newChunks[chunkIndex].audioBlob = blob;
      newChunks[chunkIndex].status = 'success';
      setChunks([...newChunks]);

      // Check if all chunks are success now, if so, merge
      if (newChunks.every(c => c.status === 'success')) {
        await finalizeMerge(newChunks);
      } else {
        setProgressText("اكتمل إعادة توليد الجزء. في انتظار استكمال الأجزاء الأخرى...");
        setIsLoading(false);
        setIsGeneratingChunks(false);
      }
    } catch (err: any) {
      if (currentJobIdRef.current !== jobId) return;
      newChunks[chunkIndex].status = 'error';
      setChunks([...newChunks]);
      setError(`فشل في إعادة توليد الجزء ${chunkId}: ${err.message}`);
      setIsLoading(false);
      setIsGeneratingChunks(false);
    } finally {
      if (currentJobIdRef.current === jobId) currentJobIdRef.current = null;
    }
  };

  const finalizeMerge = async (finalChunks: ScriptChunk[]) => {
    setProgressText("دمج المقاطع...");
    setProgressPercent(100);
    try {
      const blobs = finalChunks.map(c => c.audioBlob as Blob);
      const finalBlob = await mergeAudioChunks(blobs, finalChunks.map(c => c.text), applyFinalCompression);
      
      setProgressText("فحص الملف النهائي...");
      if (finalBlob.size <= 44) {
        throw new Error("Invalid final audio generated.");
      }

      if (audioUrl) {
         URL.revokeObjectURL(audioUrl);
      }

      const url = URL.createObjectURL(finalBlob);
      setAudioUrl(url);
      setAudioBlob(finalBlob);
      setOriginalAudioBlob(finalBlob);
      setAudioData("generated");

      // Approximate duration based on file size, will be exact after first processAudio call if needed
      // Actually we don't have exact PCM length here, let's estimate
      const initialDur = (finalBlob.size - 44) / 48000;
      setOriginalDuration(initialDur);
      setProcessedDuration(initialDur);
      setProcessSuccess(null);

      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.load();
      }

      setProgressText("اكتمل التوليد");
    } catch (err: any) {
      setError(`فشل دمج الملفات: ${err.message}`);
    } finally {
      setIsLoading(false);
      setIsGeneratingChunks(false);
    }
  };

  const handleGenerate = async () => {
    if (isLoading || isProcessing || isAnalyzingEmotions || currentJobIdRef.current) return;

    if (!script.trim()) {
      setError("الرجاء إدخال نص لتوليد الصوت.");
      return;
    }

    const jobId = Date.now().toString();
    currentJobIdRef.current = jobId;

    let currentAnalysis = emotionAnalysis;
    
    // Normalize script
    const normalizedScript = normalizeScript(script);

    // Create voice profile and fingerprint
    const activeProfile: LockedVoiceProfile = Object.freeze({
      modelId: "gemini-2.5-flash-preview-tts",
      voiceId: voice,
      style,
      perfPower,
      speed,
      perfType,
      expression,
      pauses,
      articulation,
      tone,
      emotionMode,
      emotionIntensity,
      laughterControl,
      sadnessControl,
      fixedEmotion,
      highVoiceConsistency
    });
    const fingerprint = await generateVoiceFingerprint(activeProfile);
    activeProfileRef.current = activeProfile;
    activeFingerprintRef.current = fingerprint;
    setVoiceFingerprint(fingerprint);
    setLockedProfile(activeProfile);

    if (smartEmotionsEnabled && emotionMode === "تلقائي بالذكاء الاصطناعي" && !currentAnalysis && !emotionAnalysisError) {
      currentAnalysis = await handleAnalyzeEmotions(true);
      if (!currentAnalysis) {
        currentJobIdRef.current = null;
        return;
      }
    }

    setIsLoading(true);
    setIsGeneratingChunks(true);
    setError(null);
    setAudioData(null);
    setAudioBlob(null);
    setOriginalAudioBlob(null);
    if (audioUrl) {
       URL.revokeObjectURL(audioUrl);
       setAudioUrl(null);
    }

    setProgressText("تجهيز وتقسيم النص");
    setProgressPercent(0);

    const words = normalizedScript.trim().split(/\s+/).filter(w => w.length > 0).length;
    const effectiveTargetSize = getEffectiveTargetSize(words);
    
    // Resume logic: if we already have chunks and they match the text, reuse them
    let newChunks = chunks.length > 0 && chunks.map(c => c.text).join(" ").length >= normalizedScript.length * 0.9 ? [...chunks] : [];
    if (newChunks.length === 0) {
      newChunks = splitScriptIntoChunks(normalizedScript, effectiveTargetSize);
    }
    setChunks(newChunks);



    let chunksToProcess = newChunks.map((_, index) => index).filter(i => newChunks[i].status !== 'success');
    let hasError = false;
    let concurrency =
      genMode === "توليد كل الأجزاء معًا"
        ? Math.max(1, chunksToProcess.length)
        : genMode === "توليد سريع — 5 أجزاء معًا"
          ? parseInt(localStorage.getItem('tts_activeConcurrency') || "5")
          : 1;
    const retryCounts = new Map<number, number>();

    while (chunksToProcess.length > 0) {
      if (currentJobIdRef.current !== jobId) break; // cancelled
      
      let currentBatchIndices = chunksToProcess.slice(0, concurrency);
      chunksToProcess = chunksToProcess.slice(concurrency);
      
      setProgressText(`توليد الأجزاء ${currentBatchIndices[0] + 1} إلى ${currentBatchIndices[currentBatchIndices.length - 1] + 1} من ${newChunks.length}`);
      setProgressPercent(Math.round(((newChunks.length - chunksToProcess.length - currentBatchIndices.length) / newChunks.length) * 100));

      const batchPromises = currentBatchIndices.map(async (actualIndex) => {
        const chunk = newChunks[actualIndex];
        
        let emotionInstructionsText = "";
        if (smartEmotionsEnabled) {
          if (emotionMode === "تلقائي بالذكاء الاصطناعي" && currentAnalysis) {
             const chunkText = chunk.text;
             const relevantEmotions = currentAnalysis.filter((e: any) => chunkText.includes(e.text) || e.text.includes(chunkText));
             emotionInstructionsText = relevantEmotions.length > 0 
               ? relevantEmotions.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n")
               : currentAnalysis.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n");
          } else if (emotionMode === "شعور ثابت للنص كاملًا") {
             emotionInstructionsText = `Apply the following emotion to the entire script: ${fixedEmotion}`;
          } else if (emotionMode === "تحديد يدوي داخل النص" && manualEmotions.length > 0) {
             emotionInstructionsText = manualEmotions.map((e: any) => `[${e.emotion}] ${e.text}`).join("\n");
          }
        }

        try {
          const blob = await generateChunk(chunk, emotionInstructionsText, jobId, activeProfile);
          if (currentJobIdRef.current !== jobId) return { index: actualIndex, success: false, cancelled: true };
          
          newChunks[actualIndex].audioBlob = blob;
          newChunks[actualIndex].status = 'success';
          return { index: actualIndex, success: true };
        } catch (err: any) {
          if (currentJobIdRef.current !== jobId) return { index: actualIndex, success: false, cancelled: true };
          newChunks[actualIndex].status = 'error';
          
          return { index: actualIndex, success: false, error: err };
        }
      });

      // Mark batch as generating in UI before waiting
      currentBatchIndices.forEach((actualIndex) => {
        if (newChunks[actualIndex].status !== 'success') newChunks[actualIndex].status = 'generating';
      });
      setChunks([...newChunks]);

      const results = await Promise.allSettled(batchPromises);
      setChunks([...newChunks]); // Update UI after batch completes
      
      let batchHas429 = false;
      let maxRetryAfterMs = 0;
      
      for (const result of results) {
         if (result.status === 'fulfilled' && !result.value.success) {
            if (result.value.cancelled) continue;
            
            const err = result.value.error;
            const actualIndex = result.value.index;
            
            if (err.status === 429 || (err.message && err.message.includes('429'))) {
                const structuredError = err.structuredError;
                if (structuredError?.quotaType === "RPD" || err.message?.includes("Daily Limit")) {
                    setError(`توقف مؤقت: استنفاد الحصة اليومية للطلبات (RPD). تم حفظ الأجزاء الناجحة. يمكنك الاستكمال لاحقاً.`);
                    hasError = true;
                } else {
                    batchHas429 = true;
                    // Put back to queue
                    chunksToProcess.unshift(actualIndex);
                    // Deduplicate
                    chunksToProcess = Array.from(new Set(chunksToProcess)).sort((a,b) => a - b);
                    if (structuredError?.retryAfterMs) {
                        maxRetryAfterMs = Math.max(maxRetryAfterMs, structuredError.retryAfterMs);
                    }
                }
            } else if (err.status === 400 || (err.message && err.message.includes('400'))) {
                setError(`فشل نهائي في الجزء ${actualIndex + 1}: ${err.message}`);
                hasError = true;
            } else {
                // Temporary/network errors get a bounded retry; completed chunks remain cached.
                const retries = (retryCounts.get(actualIndex) || 0) + 1;
                retryCounts.set(actualIndex, retries);
                if (retries <= 2) {
                  chunksToProcess.unshift(actualIndex);
                  chunksToProcess = Array.from(new Set(chunksToProcess)).sort((a,b) => a - b);
                } else {
                  setError(`فشل الجزء ${actualIndex + 1} بعد محاولتين إضافيتين: ${err.message}`);
                  hasError = true;
                }
            }
         } else if (result.status === 'rejected') {
            setError(`فشل في توليد أحد الأجزاء: حدث خطأ غير متوقع`);
            hasError = true;
         }
      }

      if (hasError) break; // Stop overall on unrecoverable error

      if (batchHas429) {
          if (concurrency > 3) {
              concurrency = 3;
              localStorage.setItem('tts_activeConcurrency', '3');
          } else if (concurrency > 1) {
              concurrency = 1;
              localStorage.setItem('tts_activeConcurrency', '1');
          }
          
          const waitTime = maxRetryAfterMs > 0 ? maxRetryAfterMs + 1000 : 65000;
          
          const endWaitTime = Date.now() + waitTime;
          while (Date.now() < endWaitTime) {
               if (currentJobIdRef.current !== jobId) break;
               const remaining = Math.ceil((endWaitTime - Date.now()) / 1000);
               setProgressText(`تم حفظ الأجزاء الناجحة. الأجزاء المتبقية في انتظار إعادة المحاولة بعد ${remaining} ثانية...`);
               await new Promise(r => setTimeout(r, 1000));
          }
      } else {
          // Delay between batches
          if (chunksToProcess.length > 0) {
             const delayMs = getDelayMs(reqDelay);
             if (delayMs > 0) {
               await new Promise(r => setTimeout(r, delayMs));
             }
          }
      }
      
      setProgressPercent(Math.round(((newChunks.length - chunksToProcess.length) / newChunks.length) * 100));
    }

    if (currentJobIdRef.current === jobId) {
      if (!hasError && newChunks.every(c => c.status === 'success')) {
        await finalizeMerge(newChunks);
      } else {
        setIsLoading(false);
        setIsGeneratingChunks(false);
      }
      currentJobIdRef.current = null;
    }
  };



  const handleStop = () => {
    currentJobIdRef.current = null;
    setIsLoading(false);
    setIsGeneratingChunks(false);
    setProgressText("تم إيقاف التوليد.");
  };

  const combineBase64ChunksToPCM = (chunks: string[]): Uint8Array => {
    let totalLength = 0;
    const byteArrays = chunks.map(chunk => {
      console.log("Chunk base64 length:", chunk.length);
      const byteCharacters = atob(chunk);
      const byteArray = new Uint8Array(byteCharacters.length);
      for (let i = 0; i < byteCharacters.length; i++) {
        byteArray[i] = byteCharacters.charCodeAt(i);
      }
      totalLength += byteArray.length;
      return byteArray;
    });

    const combined = new Uint8Array(totalLength);
    let offset = 0;
    for (const ba of byteArrays) {
      combined.set(ba, offset);
      offset += ba.length;
    }
    return combined;
  };

  const createWavBlob = (pcmData: Uint8Array, sampleRate: number): Blob => {
    const numChannels = 1;
    const bitsPerSample = 16;
    const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
    const blockAlign = (numChannels * bitsPerSample) / 8;
    
    const buffer = new ArrayBuffer(44 + pcmData.length);
    const view = new DataView(buffer);

    const writeString = (v: DataView, offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        v.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    // RIFF chunk descriptor
    writeString(view, 0, 'RIFF');
    view.setUint32(4, 36 + pcmData.length, true);
    writeString(view, 8, 'WAVE');

    // fmt sub-chunk
    writeString(view, 12, 'fmt ');
    view.setUint32(16, 16, true); // Subchunk1Size (16 for PCM)
    view.setUint16(20, 1, true); // AudioFormat (1 for PCM)
    view.setUint16(22, numChannels, true); // NumChannels
    view.setUint32(24, sampleRate, true); // SampleRate
    view.setUint32(28, byteRate, true); // ByteRate
    view.setUint16(32, blockAlign, true); // BlockAlign
    view.setUint16(34, bitsPerSample, true); // BitsPerSample

    // data sub-chunk
    writeString(view, 36, 'data');
    view.setUint32(40, pcmData.length, true);

    // Write PCM data
    const pcmView = new Uint8Array(buffer, 44);
    pcmView.set(pcmData);

    return new Blob([buffer], { type: 'audio/wav' });
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    const a = document.createElement("a");
    a.href = audioUrl;
    a.download = `egyptian-tts-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadOriginal = () => {
    if (!originalAudioBlob) return;
    const url = URL.createObjectURL(originalAudioBlob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `egyptian-tts-original-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleProcess = async (enhance: boolean, removeSilence: boolean) => {
    if (!originalAudioBlob) return;
    setIsProcessing(true);
    setError(null);
    setProcessSuccess(null);

    try {
      const result = await processAudio({
        blob: originalAudioBlob,
        enhance,
        removeSilence,
        enhancementLevel,
        silenceMode
      });

      if (audioUrl) {
        URL.revokeObjectURL(audioUrl);
      }

      const url = URL.createObjectURL(result.blob);
      setAudioUrl(url);
      setAudioBlob(result.blob);
      setProcessedDuration(result.duration);
      if (!originalDuration) setOriginalDuration(result.originalDuration);

      let msg = [];
      if (enhance) msg.push("Voice Enhanced");
      if (removeSilence) msg.push("Silences Removed");
      setProcessSuccess(`${msg.join(" and ")} successfully.`);

      if (audioRef.current) {
        audioRef.current.src = url;
        audioRef.current.load();
      }
    } catch (err: any) {
      setError("Processing failed: " + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleReset = () => {
    if (!originalAudioBlob) return;
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
    }
    const url = URL.createObjectURL(originalAudioBlob);
    setAudioUrl(url);
    setAudioBlob(originalAudioBlob);
    setProcessedDuration(originalDuration);
    setProcessSuccess("Reset to original audio.");
    if (audioRef.current) {
      audioRef.current.src = url;
      audioRef.current.load();
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-200 font-sans p-4 sm:p-8" dir="rtl">
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="flex flex-col items-center space-y-3 mt-6 mb-10">
          <div className="flex items-center justify-center gap-3 text-emerald-500 bg-emerald-500/10 p-4 rounded-full shadow-[0_0_20px_rgba(16,185,129,0.15)]">
            <Mic2 size={32} />
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-white">
            الاستوديو الصوتي
          </h1>
          <p className="text-neutral-400 max-w-xl mx-auto text-center text-sm">
            حول نصوصك إلى تعليق صوتي احترافي بجودة الاستوديو
          </p>
        </header>

        <main className="space-y-6">
          <section className="bg-neutral-900 rounded-2xl shadow-xl border border-neutral-800 overflow-hidden">
            <div className="p-5 sm:p-7 space-y-6">
              
              <div className="space-y-3 relative">
                <div className="flex items-center justify-between">
                  <label htmlFor="script" className="block text-sm font-semibold text-neutral-300 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-emerald-500" />
                    النص
                  </label>
                  {smartEmotionsEnabled && emotionMode === "تحديد يدوي داخل النص" && (
                    <div className="flex items-center gap-2">
                      <select id="manualEmotionSelect" className="text-xs rounded-lg border border-neutral-700 px-2 py-1 bg-neutral-800 text-neutral-200 focus:ring-1 focus:ring-emerald-500">
                        {SUPPORTED_EMOTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                      <button 
                        onClick={() => {
                          const textarea = document.getElementById("script") as HTMLTextAreaElement;
                          const select = document.getElementById("manualEmotionSelect") as HTMLSelectElement;
                          if (textarea && select && textarea.selectionStart !== textarea.selectionEnd) {
                            const selectedText = textarea.value.substring(textarea.selectionStart, textarea.selectionEnd);
                            const emotion = select.value;
                            setManualEmotions([...manualEmotions, { text: selectedText, emotion }]);
                            setNotice(`تم إضافة الشعور [${emotion}] للنص المحدد.`);
                            setTimeout(() => setNotice(null), 3000);
                          } else {
                            setError("يرجى تحديد جزء من النص أولاً.");
                            setTimeout(() => setError(null), 3000);
                          }
                        }}
                        className="text-xs bg-emerald-500/10 text-emerald-400 px-3 py-1.5 rounded-lg hover:bg-emerald-500/20 transition-colors"
                      >
                        تطبيق الشعور
                      </button>
                      <button 
                        onClick={() => setManualEmotions([])}
                        className="text-xs bg-red-500/10 text-red-400 px-3 py-1.5 rounded-lg hover:bg-red-500/20 transition-colors"
                      >
                        مسح
                      </button>
                    </div>
                  )}
                </div>

            <div className="space-y-4 pt-2">
              <div className="flex items-center justify-between border-t border-neutral-800 pt-5 mt-2">
                <button
                  onClick={() => setIsChunksPreviewOpen(!isChunksPreviewOpen)}
                  className="flex items-center gap-2 text-sm font-semibold text-emerald-500 hover:text-emerald-400 transition-colors w-full justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Layers className="w-4 h-4" />
                    {isChunksPreviewOpen ? "إخفاء أجزاء السكربت والإعدادات" : "أجزاء السكربت والإعدادات"}
                  </span>
                  {isChunksPreviewOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>

              {isChunksPreviewOpen && (
                <div className="bg-neutral-800/30 rounded-2xl border border-neutral-700/50 p-5 space-y-6 animate-in slide-in-from-top-2 text-right">
                  <div className="space-y-3">
                    <label className="block text-xs font-semibold text-neutral-400">حجم الجزء (كلمة)</label>
                    <div className="flex items-center gap-2 justify-end flex-wrap">
                      {["100 كلمة", "150 كلمة", "200 كلمة", "250 كلمة", "300 كلمة", "تلقائي ذكي"].map(size => (
                        <button
                          key={size}
                          onClick={() => setChunkSize(size)}
                          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors border shadow-sm ${chunkSize === size ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/50' : 'bg-neutral-900 border-neutral-700 text-neutral-300 hover:bg-neutral-800'}`}
                        >
                          {size}
                        </button>
                      ))}
                    </div>
                  </div>

                  {chunks.length > 0 && (
                    <div className="pt-4 border-t border-neutral-700/50">
                      <h4 className="text-sm font-semibold text-neutral-300 mb-3 flex items-center gap-2 justify-end">
                        <Activity className="w-3.5 h-3.5 text-emerald-500" />
                        حالة الأجزاء
                      </h4>
                      <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                        {chunks.map((chunk, i) => (
                          <div key={chunk.id} className="bg-neutral-900/50 p-3 rounded-xl border border-neutral-700 text-right space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                {chunk.status === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                                {chunk.status === 'error' && (
                                  <button onClick={() => handleRetryChunk(chunk.id)} className="text-red-400 hover:text-red-300 flex items-center gap-1 text-xs">
                                    <RotateCcw className="w-3 h-3" /> إعادة
                                  </button>
                                )}
                                {chunk.status === 'generating' && <Loader2 className="w-4 h-4 text-emerald-500 animate-spin" />}
                                {chunk.status === 'pending' && <div className="w-4 h-4 rounded-full border-2 border-neutral-600 border-dashed" />}
                              </div>
                              <span className="text-xs font-mono text-neutral-400">الجزء {i + 1} | {chunk.wordCount} كلمة</span>
                            </div>
                            <p className="text-xs text-neutral-500 leading-relaxed truncate" dir="rtl">{chunk.text}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

                
                {smartEmotionsEnabled && emotionMode === "تحديد يدوي داخل النص" && manualEmotions.length > 0 && (
                  <div className="bg-neutral-800/50 p-3 rounded-lg border border-neutral-700/50 text-xs flex flex-wrap gap-2 text-right justify-start">
                    {manualEmotions.map((m, i) => (
                      <div key={i} className="bg-neutral-800 px-2.5 py-1.5 rounded-md border border-neutral-700 flex items-center gap-2 shadow-sm">
                        <span className="text-emerald-400 font-bold">[{m.emotion}]</span>
                        <span className="text-neutral-300 max-w-[150px] truncate">{m.text}</span>
                        <button onClick={() => setManualEmotions(manualEmotions.filter((_, idx) => idx !== i))} className="text-red-400 hover:text-red-300 transition-colors">×</button>
                      </div>
                    ))}
                  </div>
                )}
                <div className="relative">
                  <textarea
                    id="script"
                    value={script}
                    onChange={(e) => {
                      setScript(e.target.value);
                      setEmotionAnalysis(null);
                      setEmotionAnalysisError(null);
                      setChunks([]);
                    }}
                    placeholder="اكتب أو الصق النص هنا..."
                    dir="auto"
                    className="w-full h-48 sm:h-56 rounded-xl border border-neutral-700 bg-neutral-950/50 p-5 text-base text-neutral-100 placeholder:text-neutral-600 focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all resize-none shadow-inner leading-relaxed"
                  />
                  <div className="absolute bottom-4 left-4 text-xs font-mono text-neutral-500 bg-neutral-900/80 px-2 py-1 rounded border border-neutral-800 backdrop-blur-sm">
                    {script.length} حرف
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="space-y-2">
                  <label htmlFor="voice" className="block text-sm font-semibold text-neutral-300 flex items-center gap-2">
                    <Mic2 className="w-4 h-4 text-emerald-500" />
                    الصوت
                  </label>
                  <div className="relative">
                    <select
                      id="voice"
                      value={voice}
                      onChange={(e) => {
                        setVoice(e.target.value);
                        localStorage.setItem('tts_voice', e.target.value);
                      }}
                      className="w-full appearance-none rounded-xl border border-neutral-700 bg-neutral-800 py-3 px-4 pl-10 text-sm text-white focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all shadow-sm outline-none"
                    >
                      {VOICES.map((v) => (
                        <option key={v} value={v}>
                          {v} ({VOICE_GENDERS[v] === 'male' ? 'رجل' : 'امرأة'})
                        </option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-neutral-500">
                      <ChevronDown className="h-4 w-4" />
                    </div>
                  </div>
                </div>
                <div className="space-y-2">
                  <label htmlFor="style" className="block text-sm font-semibold text-neutral-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-emerald-500" />
                    الاستايل
                  </label>
                  <div className="relative">
                    <select
                      id="style"
                      value={style}
                      onChange={handleStyleChange}
                      className="w-full appearance-none rounded-xl border border-neutral-700 bg-neutral-800 py-3 px-4 pl-10 text-sm text-white focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all shadow-sm outline-none"
                    >
                      {STYLES.map((s) => (
                        <option key={s} value={s}>
                          {s}
                        </option>
                      ))}
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-neutral-500">
                      <ChevronDown className="h-4 w-4" />
                    </div>
                  </div>
                </div>
              </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between border-t border-neutral-800 pt-5 mt-2">
                <button
                  onClick={() => setIsPerfSettingsOpen(!isPerfSettingsOpen)}
                  className="flex items-center gap-2 text-sm font-semibold text-emerald-500 hover:text-emerald-400 transition-colors w-full justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Settings className="w-4 h-4" />
                    {isPerfSettingsOpen ? "إخفاء إعدادات الأداء" : "إعدادات الأداء"}
                  </span>
                  {isPerfSettingsOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>

              {isPerfSettingsOpen && (
                <div className="bg-neutral-800/30 rounded-2xl border border-neutral-700/50 p-5 space-y-6 animate-in slide-in-from-top-2">
                  <div className="space-y-3">
                    <h4 className="text-sm font-semibold text-neutral-300 text-right flex items-center gap-2">
                      <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
                      إعدادات جاهزة
                    </h4>
                    <div className="flex flex-wrap gap-2 justify-end">
                      {Object.keys({ ...PRESETS, ...customPresets }).map((presetKey) => {
                        const allPresets = { ...PRESETS, ...customPresets };
                        return (
                          <div key={presetKey} className="flex items-stretch border border-neutral-700 rounded-lg overflow-hidden group shadow-sm">
                            <button
                              onClick={() => applyPreset(presetKey, allPresets[presetKey])}
                              className={`px-3 py-1.5 text-xs font-semibold transition-all ${activePreset === presetKey ? "bg-emerald-500 text-neutral-950" : "bg-neutral-800 text-neutral-300 hover:bg-neutral-700"}`}
                            >
                              {presetKey}
                            </button>
                            {!PRESETS[presetKey] && (
                              <div className={`flex items-center border-r border-neutral-700 px-1 transition-colors ${activePreset === presetKey ? "bg-emerald-400" : "bg-neutral-800"}`}>
                                <button
                                  onClick={() => renameCustomPreset(presetKey)}
                                  className={`p-1 transition-colors ${activePreset === presetKey ? "text-emerald-900 hover:text-black" : "text-neutral-400 hover:text-blue-400"}`}
                                  title="تغيير الاسم"
                                >
                                  <Edit2 className="w-3 h-3" />
                                </button>
                                <button
                                  onClick={() => deleteCustomPreset(presetKey)}
                                  className={`p-1 transition-colors ${activePreset === presetKey ? "text-emerald-900 hover:text-red-900" : "text-neutral-400 hover:text-red-400"}`}
                                  title="حذف"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 text-right">
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">قوة الأداء</label>
                      <select value={perfPower} onChange={(e) => handlePerfChange(setPerfPower, 'tts_perfPower', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_PERF_POWER.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">سرعة الكلام</label>
                      <select value={speed} onChange={(e) => handlePerfChange(setSpeed, 'tts_speed', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_SPEED.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">نوع الأداء</label>
                      <select value={perfType} onChange={(e) => handlePerfChange(setPerfType, 'tts_perfType', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_PERF_TYPE.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">التعبير والانفعال</label>
                      <select value={expression} onChange={(e) => handlePerfChange(setExpression, 'tts_expression', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_EXPRESSION.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">الوقفات</label>
                      <select value={pauses} onChange={(e) => handlePerfChange(setPauses, 'tts_pauses', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_PAUSES.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">وضوح النطق</label>
                      <select value={articulation} onChange={(e) => handlePerfChange(setArticulation, 'tts_articulation', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_ARTICULATION.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                    <div className="space-y-1.5">
                      <label className="block text-xs font-semibold text-neutral-400">النبرة</label>
                      <select value={tone} onChange={(e) => handlePerfChange(setTone, 'tts_tone', e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                        {OPTIONS_TONE.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-4 pt-4 border-t border-neutral-700/50 mt-2">
                    <button
                      onClick={() => {
                        const name = window.prompt("اسم الإعداد الجاهز الجديد:");
                        if (name) {
                          const custom = { ...customPresets };
                          custom[name] = { perfPower, speed, perfType, expression, pauses, articulation, tone };
                          localStorage.setItem("tts_custom_presets", JSON.stringify(custom));
                          setCustomPresets(custom);
                          setActivePreset(name);
                          localStorage.setItem('tts_preset', name);
                          setLastSelectedPreset(name);
                          localStorage.setItem('tts_lastSelectedPreset', name);
                        }
                      }}
                      className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors bg-emerald-500/10 px-3 py-1.5 rounded-lg hover:bg-emerald-500/20"
                    >
                      + حفظ كإعداد جديد
                    </button>
                    <button
                      onClick={() => {
                        const settings = PRESETS[lastSelectedPreset] || customPresets[lastSelectedPreset];
                        if (settings) {
                          applyPreset(lastSelectedPreset, settings);
                        }
                      }}
                      disabled={!PRESETS[lastSelectedPreset] && !customPresets[lastSelectedPreset]}
                      className="text-xs flex items-center gap-1.5 font-semibold text-neutral-400 hover:text-neutral-200 transition-colors disabled:opacity-30"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      العودة للإعداد الأصلي
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between border-t border-neutral-800 pt-5 mt-2">
                <button
                  onClick={() => setIsEmotionsPanelOpen(!isEmotionsPanelOpen)}
                  className="flex items-center gap-2 text-sm font-semibold text-emerald-500 hover:text-emerald-400 transition-colors w-full justify-between"
                >
                  <span className="flex items-center gap-2">
                    <Wand2 className="w-4 h-4" />
                    {isEmotionsPanelOpen ? "إخفاء المشاعر الذكية" : "المشاعر الذكية"}
                  </span>
                  {isEmotionsPanelOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>
              </div>

              {isEmotionsPanelOpen && (
                <div className="bg-neutral-800/30 rounded-2xl border border-neutral-700/50 p-5 space-y-6 animate-in slide-in-from-top-2 text-right">
                  <div className="flex items-center justify-between mb-2">
                    <label className="flex items-center gap-3 cursor-pointer text-sm font-semibold text-neutral-300">
                      <input 
                        type="checkbox" 
                        checked={smartEmotionsEnabled}
                        onChange={(e) => setSmartEmotionsEnabled(e.target.checked)}
                        className="w-4 h-4 text-emerald-500 bg-neutral-900 border-neutral-600 rounded focus:ring-emerald-500 focus:ring-offset-neutral-900"
                      />
                      تفعيل المشاعر الذكية
                    </label>
                  </div>

                  {smartEmotionsEnabled && (
                    <>
                      <div className="space-y-3">
                        <h4 className="text-sm font-semibold text-neutral-400">إعدادات جاهزة (مشاعر)</h4>
                        <div className="flex flex-wrap gap-2 justify-end">
                          {Object.keys(EMOTION_PRESETS).map((presetKey) => (
                            <button
                              key={presetKey}
                              onClick={() => applyEmotionPreset(presetKey, EMOTION_PRESETS[presetKey])}
                              className="px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors border bg-neutral-900 border-neutral-700 text-neutral-300 hover:bg-neutral-800 hover:text-white shadow-sm"
                            >
                              {presetKey}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        <div className="space-y-1.5">
                          <label className="block text-xs font-semibold text-neutral-400">طريقة تحديد المشاعر</label>
                          <select value={emotionMode} onChange={(e) => setEmotionMode(e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                            {EMOTION_MODES.map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                        </div>
                        <div className="space-y-1.5">
                          <label className="block text-xs font-semibold text-neutral-400">قوة المشاعر</label>
                          <select value={emotionIntensity} onChange={(e) => setEmotionIntensity(e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                            {EMOTION_INTENSITIES.map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                        </div>
                        <div className="space-y-1.5">
                          <label className="block text-xs font-semibold text-neutral-400">الضحك</label>
                          <select value={laughterControl} onChange={(e) => setLaughterControl(e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                            {LAUGHTER_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                        </div>
                        <div className="space-y-1.5">
                          <label className="block text-xs font-semibold text-neutral-400">التأثر والحزن</label>
                          <select value={sadnessControl} onChange={(e) => setSadnessControl(e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                            {SADNESS_OPTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                        </div>
                        {emotionMode === "شعور ثابت للنص كاملًا" && (
                          <div className="space-y-1.5">
                            <label className="block text-xs font-semibold text-neutral-400">الشعور الثابت</label>
                            <select value={fixedEmotion} onChange={(e) => setFixedEmotion(e.target.value)} className="w-full text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none">
                              {SUPPORTED_EMOTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                            </select>
                          </div>
                        )}
                      </div>

                      {emotionMode === "تحديد يدوي داخل النص" && (
                        <div className="p-3 bg-neutral-900 border border-neutral-700 rounded-lg text-sm text-neutral-400 text-center">
                          ظلل جزء من النص في الأعلى، ثم اضغط على "تطبيق الشعور على التحديد".
                        </div>
                      )}

                      {emotionMode === "تلقائي بالذكاء الاصطناعي" && (
                        <div className="pt-5 border-t border-neutral-700/50 mt-2">
                          <div className="flex items-center justify-between mb-4">
                            <button
                              onClick={handleAnalyzeEmotions}
                              disabled={isAnalyzingEmotions || !script.trim()}
                              className="text-xs bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-lg font-semibold transition-colors disabled:opacity-30 flex items-center gap-2"
                            >
                              {isAnalyzingEmotions ? <Loader2 className="w-3 h-3 animate-spin" /> : <Wand2 className="w-3 h-3" />}
                              تحليل المشاعر
                            </button>
                            <h4 className="text-sm font-semibold text-neutral-300 flex items-center gap-2">
                              <Activity className="w-3.5 h-3.5 text-emerald-500" />
                              معاينة تحليل المشاعر
                            </h4>
                          </div>

                          {emotionAnalysisError && (
                            <div className="text-xs text-red-400 mb-3 bg-red-500/10 p-2 rounded border border-red-500/20">{emotionAnalysisError}</div>
                          )}

                          {emotionAnalysis && emotionAnalysis.length > 0 && (
                            <div className="space-y-2 bg-neutral-900/50 p-4 rounded-xl border border-neutral-700 max-h-60 overflow-y-auto">
                              {emotionAnalysis.map((item, index) => (
                                <div key={index} className="flex flex-col gap-2 pb-3 border-b border-neutral-800 last:border-0 last:pb-0">
                                  <div className="flex items-center justify-between">
                                    <select 
                                      value={item.emotion}
                                      onChange={(e) => {
                                        const newAnalysis = [...emotionAnalysis];
                                        newAnalysis[index].emotion = e.target.value;
                                        setEmotionAnalysis(newAnalysis);
                                      }}
                                      className="text-xs rounded-lg border border-neutral-700 bg-neutral-800 text-emerald-400 font-semibold py-1 px-2 outline-none focus:ring-1 focus:ring-emerald-500"
                                    >
                                      {SUPPORTED_EMOTIONS.map(o => <option key={o} value={o}>{o}</option>)}
                                    </select>
                                    <span className="text-xs text-neutral-500 font-mono">الجملة {index + 1}</span>
                                  </div>
                                  <p className="text-sm text-neutral-300 leading-relaxed">{item.text}</p>
                                </div>
                              ))}
                            </div>
                          )}
                          {!emotionAnalysis && !isAnalyzingEmotions && (
                            <div className="text-xs text-neutral-500 text-center py-3 bg-neutral-900/30 rounded-lg border border-neutral-800 border-dashed">
                              لم يتم التحليل بعد. اضغط على الزر أعلاه أو "توليد الصوت".
                            </div>
                          )}
                        </div>
                      )}
                    </>
                  )}
                </div>
              )}
            </div>

        {notice && (
              <div className="bg-emerald-500/10 text-emerald-400 p-4 rounded-2xl flex items-start gap-3 border border-emerald-500/20 animate-in fade-in">
                <CheckCircle2 className="w-5 h-5 mt-0.5 shrink-0" />
                <p className="text-sm font-semibold">{notice}</p>
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 text-red-400 p-4 rounded-2xl flex items-start gap-3 border border-red-500/20">
                <AlertCircle className="w-5 h-5 mt-0.5 shrink-0" />
                <p className="text-sm font-semibold">{error}</p>
              </div>
            )}

            <div className="bg-neutral-800/30 p-5 rounded-2xl border border-neutral-700/50 mb-6 space-y-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1.5 w-full sm:w-auto">
                  <label className="block text-xs font-semibold text-neutral-400 text-right">نمط التوليد</label>
                  <select 
                    value={genMode} 
                    onChange={(e) => {
                      const val = e.target.value;
                      setGenMode(val);
                      localStorage.setItem('tts_genMode', val);
                      if (val === "توليد سريع — 5 أجزاء معًا") {
                         localStorage.setItem('tts_activeConcurrency', '5');
                      }
                    }} 
                    className="w-full sm:w-64 text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none text-right"
                  >
                    <option value="توليد كل الأجزاء معًا">توليد كل الأجزاء معًا (مثل النسخة القديمة)</option>
                    <option value="توليد سريع — 5 أجزاء معًا">توليد سريع — 5 أجزاء معًا</option>
                    <option value="توفير الكوتا مع ثبات النبرة">توفير الكوتا مع ثبات النبرة</option>
                    <option value="تخصيص كامل">تخصيص كامل (مع المشاعر)</option>
                  </select>
                </div>
                <div className="space-y-1.5 w-full sm:w-auto">
                  <label className="block text-xs font-semibold text-neutral-400 text-right">ثبات الصوت</label>
                  <label className="flex items-center justify-end gap-2 text-sm bg-neutral-900 px-3 py-2 rounded-lg border border-neutral-700 cursor-pointer">
                    <span className="text-white">ثبات الصوت العالي</span>
                    <input 
                      type="checkbox" 
                      checked={highVoiceConsistency}
                      onChange={(e) => {
                        setHighVoiceConsistency(e.target.checked);
                        localStorage.setItem('tts_highVoiceConsistency', e.target.checked.toString());
                      }}
                      className="w-4 h-4 text-emerald-500 bg-neutral-800 border-neutral-600 rounded focus:ring-emerald-500 focus:ring-offset-neutral-900"
                    />
                  </label>
                </div>
                <div className="space-y-1.5 w-full sm:w-auto">
                  <label className="block text-xs font-semibold text-neutral-400 text-right">معالجة الصوت</label>
                  <label className="flex items-center justify-end gap-2 text-sm bg-neutral-900 px-3 py-2 rounded-lg border border-neutral-700 cursor-pointer">
                    <span className="text-white">تطبيق ضغط الصوت النهائي</span>
                    <input 
                      type="checkbox" 
                      checked={applyFinalCompression}
                      onChange={(e) => {
                        setApplyFinalCompression(e.target.checked);
                        localStorage.setItem('tts_applyFinalCompression', e.target.checked.toString());
                      }}
                      className="w-4 h-4 text-emerald-500 bg-neutral-800 border-neutral-600 rounded focus:ring-emerald-500 focus:ring-offset-neutral-900"
                    />
                  </label>
                </div>
                <div className="space-y-1.5 w-full sm:w-auto">
                  <label className="block text-xs font-semibold text-neutral-400 text-right">التأخير بين الطلبات</label>
                  <select 
                    value={reqDelay} 
                    onChange={(e) => {
                      setReqDelay(e.target.value);
                      localStorage.setItem('tts_reqDelay', e.target.value);
                    }} 
                    className="w-full sm:w-48 text-sm rounded-lg border-neutral-700 bg-neutral-900 text-white py-2 px-3 focus:ring-1 focus:ring-emerald-500 outline-none text-right"
                  >
                    <option value="بدون تأخير">بدون تأخير</option>
                    <option value="5 ثوانٍ">5 ثوانٍ</option>
                    <option value="10 ثوانٍ">10 ثوانٍ</option>
                    <option value="20 ثانية">20 ثانية</option>
                  </select>
                </div>
              </div>

              {script.trim() && (() => {
                const s = calculateStats();
                if (!s) return null;
                return (
                  <div className="pt-4 border-t border-neutral-700/50 text-right text-sm">
                    <h4 className="text-emerald-400 font-semibold mb-3 flex items-center justify-end gap-2">
                      <Activity className="w-4 h-4" /> توقعات الاستهلاك
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-neutral-300 bg-neutral-900/50 p-3 rounded-xl border border-neutral-800">
                      <div>
                        <div className="text-xs text-neutral-500">حروف/كلمات</div>
                        <div className="font-mono">{s.totalChars} / {s.words}</div>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500">حجم الجزء المحدد</div>
                        <div className="font-mono">{s.effectiveTargetSize}</div>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500">أجزاء الصوت</div>
                        <div className="font-mono">{s.totalChunks}</div>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500">طلبات الصوت</div>
                        <div className="font-mono">{s.ttsRequests}</div>
                      </div>
                      <div>
                        <div className="text-xs text-neutral-500">طلبات المشاعر</div>
                        <div className="font-mono">{s.analysisReqs}</div>
                      </div>
                    </div>
                    <div className="mt-3 text-center bg-emerald-500/10 text-emerald-400 p-2 rounded-lg border border-emerald-500/20 font-bold">
                      إجمالي طلبات Gemini: {s.totalExpected}
                    </div>
                    {s.totalExpected > 10 && (
                      <div className="mt-2 text-center bg-amber-500/10 text-amber-400 p-2 rounded-lg border border-amber-500/20 text-xs flex items-center justify-center gap-2">
                        <AlertCircle className="w-4 h-4" />
                        هذا النص يحتاج إلى عدد كبير من الطلبات وقد يصل إلى حد الكوتا. يُفضّل زيادة حجم الجزء.
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            <div className="pt-2 text-right text-xs text-neutral-400 bg-neutral-800/30 p-3 rounded-xl border border-neutral-700/50 mb-4 flex flex-col gap-2">
              <div className="flex justify-between items-center w-full">
                <div>
                  <span className="font-semibold text-neutral-300">طلبات API الفعلية: </span>
                  <span className="font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">{actualReqCount}</span>
                </div>
                <div dir="rtl">
                  <span className="font-semibold text-neutral-300">الملخص: </span>
                  {style.replace('ال', '')} — {VOICE_GENDERS[voice] === "male" ? "صوت رجالي" : "صوت نسائي"} — {perfType} — {speed} — {perfPower} — وقفات {pauses}
                </div>
              </div>
              {voiceFingerprint && (
                <div className="flex justify-between items-center w-full border-t border-neutral-700/50 pt-2 mt-1">
                  <div className="flex gap-2">
                    <span className="font-semibold text-emerald-400">Voice Lock Active 🔒</span>
                  </div>
                  <div className="font-mono text-[10px] text-neutral-500 bg-neutral-900 px-2 py-1 rounded">
                    ID: {voiceFingerprint}
                  </div>
                </div>
              )}
            </div>

            <div className="flex gap-3 w-full">
              <button
                onClick={handleGenerate}
                disabled={isLoading || isProcessing || isAnalyzingEmotions || !script.trim()}
                className="flex-1 bg-emerald-500 hover:bg-emerald-400 disabled:bg-neutral-800 disabled:text-neutral-500 disabled:cursor-not-allowed text-neutral-950 px-6 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-colors shadow-lg"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    {progressText ? `${progressText} ${progressPercent > 0 && progressPercent < 100 ? `(${progressPercent}%)` : ''}` : "Generating Audio..."}
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5" fill="currentColor" />
                    Generate Audio
                  </>
                )}
              </button>
              
              {isLoading && (
                <button
                  onClick={handleStop}
                  className="bg-red-500/20 hover:bg-red-500/30 text-red-500 px-6 py-4 rounded-2xl font-bold flex items-center justify-center transition-colors border border-red-500/30"
                  title="إيقاف التوليد"
                >
                  إيقاف
                </button>
              )}
            </div>
          </div>
          </section>

          {audioUrl && (
            <div className="bg-neutral-900 border border-neutral-800 p-6 rounded-3xl space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-500 mt-6 shadow-xl relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-emerald-500/0 via-emerald-500/50 to-emerald-500/0"></div>
              
              <div className="space-y-4">
                <h3 className="text-sm font-semibold text-neutral-400 uppercase tracking-wider flex items-center gap-2">
                  <Play className="w-4 h-4" />
                  Preview
                </h3>
                <audio
                  ref={audioRef}
                  controls
                  src={audioUrl}
                  className="w-full rounded-full bg-neutral-800"
                />
                
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    onClick={handleDownload}
                    className="flex-1 sm:flex-none bg-emerald-500 hover:bg-emerald-400 text-neutral-950 px-5 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-colors shadow-md"
                  >
                    <Download className="w-4 h-4" />
                    Download WAV
                  </button>
                  <button
                    onClick={handleDownloadOriginal}
                    className="flex-1 sm:flex-none bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border border-neutral-700 px-5 py-2.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors shadow-sm"
                  >
                    <Download className="w-4 h-4" />
                    Original
                  </button>
                </div>
              </div>

              {processSuccess && (
                <div className="bg-emerald-500/10 text-emerald-400 p-3 rounded-xl flex items-center gap-2 border border-emerald-500/20">
                  <CheckCircle2 className="w-5 h-5 shrink-0" />
                  <p className="text-sm font-semibold">{processSuccess}</p>
                </div>
              )}

              <div className="border-t border-neutral-800 pt-6">
                <h3 className="text-base font-semibold text-neutral-200 mb-4 flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-emerald-500" />
                  Audio Processing
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-4 p-5 bg-neutral-800/50 rounded-2xl border border-neutral-700/50">
                    <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                      <Wand2 className="w-5 h-5" />
                      Voice Enhancement
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">Clean noise, improve clarity, and normalize levels.</p>
                    <div className="space-y-2">
                      <select
                        value={enhancementLevel}
                        onChange={(e) => setEnhancementLevel(e.target.value as EnhancementLevel)}
                        disabled={isProcessing}
                        className="w-full appearance-none rounded-xl border border-neutral-700 bg-neutral-900 text-white py-2.5 px-3 text-sm focus:ring-1 focus:ring-emerald-500 outline-none transition-all shadow-sm disabled:opacity-50"
                      >
                        <option value="Light">Light</option>
                        <option value="Balanced">Balanced (Default)</option>
                        <option value="Strong">Strong</option>
                      </select>
                    </div>
                    <button
                      onClick={() => handleProcess(true, false)}
                      disabled={isProcessing}
                      className="w-full bg-neutral-700 hover:bg-neutral-600 text-white disabled:opacity-50 px-4 py-2.5 rounded-xl font-semibold text-sm transition-colors"
                    >
                      Enhance Voice
                    </button>
                  </div>

                  <div className="space-y-4 p-5 bg-neutral-800/50 rounded-2xl border border-neutral-700/50">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                        <Scissors className="w-5 h-5" />
                        Silence Remover
                      </div>
                      {(originalDuration !== null && processedDuration !== null && originalDuration > processedDuration) && (
                        <span className="text-xs font-bold bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded-lg border border-emerald-500/20">
                          -{(originalDuration - processedDuration).toFixed(2)}s saved
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-400 leading-relaxed">Shorten long pauses while keeping natural rhythm.</p>
                    <div className="space-y-2">
                      <select
                        value={silenceMode}
                        onChange={(e) => setSilenceMode(e.target.value as SilenceMode)}
                        disabled={isProcessing}
                        className="w-full appearance-none rounded-xl border border-neutral-700 bg-neutral-900 text-white py-2.5 px-3 text-sm focus:ring-1 focus:ring-emerald-500 outline-none transition-all shadow-sm disabled:opacity-50"
                      >
                        <option value="Light">Light</option>
                        <option value="Balanced">Balanced (Default)</option>
                        <option value="Aggressive">Aggressive</option>
                      </select>
                    </div>
                    <button
                      onClick={() => handleProcess(false, true)}
                      disabled={isProcessing}
                      className="w-full bg-neutral-700 hover:bg-neutral-600 text-white disabled:opacity-50 px-4 py-2.5 rounded-xl font-semibold text-sm transition-colors"
                    >
                      Remove Silences
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3 mt-4">
                  <button
                    onClick={() => handleProcess(true, true)}
                    disabled={isProcessing}
                    className="flex-1 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 disabled:opacity-50 px-5 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors border border-emerald-500/20"
                  >
                    {isProcessing ? (
                      <><Loader2 className="w-4 h-4 animate-spin" /> Processing...</>
                    ) : (
                      "Apply Both"
                    )}
                  </button>
                  <button
                    onClick={handleReset}
                    disabled={isProcessing || processedDuration === originalDuration}
                    className="flex-1 bg-neutral-800 hover:bg-neutral-700 text-neutral-300 disabled:opacity-50 px-5 py-3 rounded-xl font-semibold flex items-center justify-center gap-2 transition-colors border border-neutral-700"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Reset to Original
                  </button>
                </div>
                
                <div className="mt-5 text-center text-xs text-neutral-500 font-mono">
                  Duration: {processedDuration?.toFixed(2)}s {originalDuration !== processedDuration ? `(Original: ${originalDuration?.toFixed(2)}s)` : ''}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
